import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'anms-stand4',
  templateUrl: './stand4.component.html',
  styleUrls: ['./stand4.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Stand4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
