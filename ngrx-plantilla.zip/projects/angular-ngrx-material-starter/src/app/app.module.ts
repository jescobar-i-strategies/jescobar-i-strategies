import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { CoreModule } from './core/core.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app/app.component';
import { Sala1Component } from './sala1/sala1.component';
import { Stand1Component } from './stand1/stand1.component';
import { Stand2Component } from './stand2/stand2.component';
import { Stand3Component } from './stand3/stand3.component';
import { Stand4Component } from './stand4/stand4.component';

@NgModule({
  imports: [
    // angular
    BrowserAnimationsModule,
    BrowserModule,

    // core
    CoreModule,

    // app
    AppRoutingModule
  ],
  declarations: [AppComponent, Sala1Component, Stand1Component, Stand2Component, Stand3Component, Stand4Component],
  bootstrap: [AppComponent]
})
export class AppModule {}
