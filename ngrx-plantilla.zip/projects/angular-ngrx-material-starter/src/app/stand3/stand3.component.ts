import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'anms-stand3',
  templateUrl: './stand3.component.html',
  styleUrls: ['./stand3.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Stand3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
