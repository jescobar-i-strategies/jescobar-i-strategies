import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'anms-stand2',
  templateUrl: './stand2.component.html',
  styleUrls: ['./stand2.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Stand2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
