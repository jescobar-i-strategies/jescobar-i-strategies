import { createAction } from '@ngrx/store';

export const authLogin = createAction('[Auth] Login');
export const authLogout = createAction('[Auth] Logout');
