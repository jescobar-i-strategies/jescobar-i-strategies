import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'anms-stand1',
  templateUrl: './stand1.component.html',
  styleUrls: ['./stand1.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Stand1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
