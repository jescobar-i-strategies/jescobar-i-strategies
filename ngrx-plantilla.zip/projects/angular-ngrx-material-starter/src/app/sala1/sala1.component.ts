import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'anms-sala1',
  templateUrl: './sala1.component.html',
  styleUrls: ['./sala1.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Sala1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
